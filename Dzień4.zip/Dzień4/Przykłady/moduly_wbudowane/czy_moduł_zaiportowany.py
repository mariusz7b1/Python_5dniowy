import sys

# Sprawdzenie, czy moduł 'numpy' został już zaimportowany
if 'numpy' in sys.modules:
    print("Moduł 'numpy' został zaimportowany.")
else:
    print("Moduł 'numpy' nie został jeszcze zaimportowany.")
