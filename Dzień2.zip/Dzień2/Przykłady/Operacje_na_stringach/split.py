#   1s  2sp  3sp
s1=" Ala  ma   kota"
s2=";Ala;;ma;;;kota"

print(s1.split())
print(s1.split(" "))
print(s2.split(";"))
