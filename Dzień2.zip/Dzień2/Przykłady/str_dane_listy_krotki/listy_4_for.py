"""
Listy - for
"""
from os import system
system('cls')

moja_lista = ["biały", "różowy", "niebieski", "żółty", "zielony"]
for kolor in moja_lista:
    print(kolor)

#  z wyk indeksu
for i in range(0, len(moja_lista)):
    print(moja_lista[i])
